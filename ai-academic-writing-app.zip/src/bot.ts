// ============ AI Bot Class - Complete Full Code ============

export class Bot {
  email: string = '';
  token: string = '';
  fingerprint: string = '';
  fbp: string = '';
  website: string = '';
  user: string = '';
  chat: string = '';
  balance: number = 0;
  cache: string = '';

  constructor() {
    this.fingerprint = this.md5(this.randomBytes(16));
    this.fbp = `fb.1.${Date.now()}.${this.randomInt(100000000000, 999999999999)}`;
    this.website = this.randomUUID();
  }

  // ==================== دوال مساعدة ====================

  randomBytes(length: number): string {
    let result = '';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  randomInt(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  randomUUID(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  // ==================== دالة MD5 كاملة ====================

  md5(string: string): string {
    function md5cycle(x: number[], _k: number[]) {
      let a = x[0], b = x[1], c = x[2], d = x[3];

      const ff = (a: number, b: number, c: number, d: number, x: number, s: number, t: number) => {
        a = a + (b & c | ~b & d) + x + t;
        return (a << s | a >>> (32 - s)) + b;
      };
      const gg = (a: number, b: number, c: number, d: number, x: number, s: number, t: number) => {
        a = a + (b & d | c & ~d) + x + t;
        return (a << s | a >>> (32 - s)) + b;
      };
      const hh = (a: number, b: number, c: number, d: number, x: number, s: number, t: number) => {
        a = a + (b ^ c ^ d) + x + t;
        return (a << s | a >>> (32 - s)) + b;
      };
      const ii = (a: number, b: number, c: number, d: number, x: number, s: number, t: number) => {
        a = a + (c ^ (b | ~d)) + x + t;
        return (a << s | a >>> (32 - s)) + b;
      };

      a |= 0; b |= 0; c |= 0; d |= 0;
      const xl = x.length;
      let offset = 0;

      while (offset < xl) {
        const originalA = a, originalB = b, originalC = c, originalD = d;

        a = ff(a, b, c, d, x[offset], 7, -680876936);
        d = ff(d, a, b, c, x[offset + 1], 12, -389564586);
        c = ff(c, d, a, b, x[offset + 2], 17, 606105819);
        b = ff(b, c, d, a, x[offset + 3], 22, -1044525330);
        a = ff(a, b, c, d, x[offset + 4], 7, -176418897);
        d = ff(d, a, b, c, x[offset + 5], 12, 1200080426);
        c = ff(c, d, a, b, x[offset + 6], 17, -1473231341);
        b = ff(b, c, d, a, x[offset + 7], 22, -45705983);
        a = ff(a, b, c, d, x[offset + 8], 7, 1770035416);
        d = ff(d, a, b, c, x[offset + 9], 12, -1958414417);
        c = ff(c, d, a, b, x[offset + 10], 17, -42063);
        b = ff(b, c, d, a, x[offset + 11], 22, -1990404162);
        a = ff(a, b, c, d, x[offset + 12], 7, 1804603682);
        d = ff(d, a, b, c, x[offset + 13], 12, -40341101);
        c = ff(c, d, a, b, x[offset + 14], 17, -1502002290);
        b = ff(b, c, d, a, x[offset + 15], 22, 1236535329);

        a = gg(a, b, c, d, x[offset + 1], 5, -165796510);
        d = gg(d, a, b, c, x[offset + 6], 9, -1069501632);
        c = gg(c, d, a, b, x[offset + 11], 14, 643717713);
        b = gg(b, c, d, a, x[offset], 20, -373897302);
        a = gg(a, b, c, d, x[offset + 5], 5, -701558691);
        d = gg(d, a, b, c, x[offset + 10], 9, 38016083);
        c = gg(c, d, a, b, x[offset + 15], 14, -660478335);
        b = gg(b, c, d, a, x[offset + 4], 20, -405537848);
        a = gg(a, b, c, d, x[offset + 9], 5, 568446438);
        d = gg(d, a, b, c, x[offset + 14], 9, -1019803690);
        c = gg(c, d, a, b, x[offset + 3], 14, -187363961);
        b = gg(b, c, d, a, x[offset + 8], 20, 1163531501);
        a = gg(a, b, c, d, x[offset + 13], 5, -1444681467);
        d = gg(d, a, b, c, x[offset + 2], 9, -51403784);
        c = gg(c, d, a, b, x[offset + 7], 14, 1735328473);
        b = gg(b, c, d, a, x[offset + 12], 20, -1926607734);

        a = hh(a, b, c, d, x[offset + 5], 4, -378558);
        d = hh(d, a, b, c, x[offset + 8], 11, -2022574463);
        c = hh(c, d, a, b, x[offset + 11], 16, 1839030562);
        b = hh(b, c, d, a, x[offset + 14], 23, -35309556);
        a = hh(a, b, c, d, x[offset + 1], 4, -1530992060);
        d = hh(d, a, b, c, x[offset + 4], 11, 1272893353);
        c = hh(c, d, a, b, x[offset + 7], 16, -155497632);
        b = hh(b, c, d, a, x[offset + 10], 23, -1094730640);
        a = hh(a, b, c, d, x[offset + 13], 4, 681279174);
        d = hh(d, a, b, c, x[offset], 11, -358537222);
        c = hh(c, d, a, b, x[offset + 3], 16, -722521979);
        b = hh(b, c, d, a, x[offset + 6], 23, 76029189);
        a = hh(a, b, c, d, x[offset + 9], 4, -640364487);
        d = hh(d, a, b, c, x[offset + 12], 11, -421815835);
        c = hh(c, d, a, b, x[offset + 15], 16, 530742520);
        b = hh(b, c, d, a, x[offset + 2], 23, -995338651);

        a = ii(a, b, c, d, x[offset], 6, -198630844);
        d = ii(d, a, b, c, x[offset + 7], 10, 1126891415);
        c = ii(c, d, a, b, x[offset + 14], 15, -1416354905);
        b = ii(b, c, d, a, x[offset + 5], 21, -57434055);
        a = ii(a, b, c, d, x[offset + 12], 6, 1700485571);
        d = ii(d, a, b, c, x[offset + 3], 10, -1894986606);
        c = ii(c, d, a, b, x[offset + 10], 15, -1051523);
        b = ii(b, c, d, a, x[offset + 1], 21, -2054922799);
        a = ii(a, b, c, d, x[offset + 8], 6, 1873313359);
        d = ii(d, a, b, c, x[offset + 15], 10, -30611744);
        c = ii(c, d, a, b, x[offset + 6], 15, -1560198380);
        b = ii(b, c, d, a, x[offset + 13], 21, 1309151649);
        a = ii(a, b, c, d, x[offset + 4], 6, -145523070);
        d = ii(d, a, b, c, x[offset + 11], 10, -1120210379);
        c = ii(c, d, a, b, x[offset + 2], 15, 718787259);
        b = ii(b, c, d, a, x[offset + 9], 21, -343485551);

        a = (a + originalA) | 0;
        b = (b + originalB) | 0;
        c = (c + originalC) | 0;
        d = (d + originalD) | 0;
        offset += 16;
      }
      return [a, b, c, d];
    }

    function md51(s: string) {
      let n = s.length, state = [1732584193, -271733879, -1732584194, 271733878], i;
      for (i = 64; i <= n; i += 64) {
        state = md5cycle(state, md5blk(s.substring(i - 64, i)));
      }
      s = s.substring(i - 64);
      const tail = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
      for (i = 0; i < s.length; i++) {
        tail[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
      }
      tail[i >> 2] |= 0x80 << ((i % 4) << 3);
      if (i > 55) {
        state = md5cycle(state, tail);
        for (i = 0; i < 16; i++) tail[i] = 0;
      }
      tail[14] = n * 8;
      state = md5cycle(state, tail);
      return state;
    }

    function md5blk(s: string) {
      const md5blks: number[] = [];
      for (let i = 0; i < 64; i += 4) {
        md5blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i + 1) << 8) + (s.charCodeAt(i + 2) << 16) + (s.charCodeAt(i + 3) << 24);
      }
      return md5blks;
    }

    const hex_chr = '0123456789abcdef'.split('');

    function rhex(n: number) {
      let s = '', j = 0;
      for (; j < 4; j++) {
        s += hex_chr[(n >> (j * 8 + 4)) & 0x0f] + hex_chr[(n >> (j * 8)) & 0x0f];
      }
      return s;
    }

    function hex(x: number[]) {
      return x.map(rhex).join('');
    }

    return hex(md51(string));
  }

  // ==================== الاتصال الأول: التسجيل ====================

  async register(): Promise<boolean> {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let randomEmail = '';
    const emailLength = 8 + Math.floor(Math.random() * 7);
    for (let i = 0; i < emailLength; i++) {
      randomEmail += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    this.email = randomEmail + "@gmail.com";
    this.fingerprint = this.md5(this.randomBytes(16));

    console.log(this.email);

    document.cookie = `referral_code=5011BC5F; path=/`;
    document.cookie = `_fbp=${this.fbp}; path=/`;

    const recaptchaChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    let recaptchaToken = '';
    const tokenLength = 1600 + Math.floor(Math.random() * 201);
    for (let i = 0; i < tokenLength; i++) {
      recaptchaToken += recaptchaChars.charAt(Math.floor(Math.random() * recaptchaChars.length));
    }

    const url = 'https://mr7.ai/api/auth/register';
    const headers: Record<string, string> = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/json',
      'origin': 'https://mr7.ai',
      'referer': 'https://mr7.ai/signup',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
    };
    const data = {
      'email': this.email,
      'password': '12323Aa4@@##',
      'deviceFingerprint': this.fingerprint,
      'recaptchaToken': recaptchaToken,
      'referralCode': '5011BC5F',
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(data),
      });

      console.log(await response.text());

      if (response.status !== 200 && response.status !== 201) {
        return false;
      }

      const result = await response.json();
      if (!result.success) {
        return false;
      }

      this.user = result.user.id;
      this.balance = result.user.tokenBalance || 0;

      const setCookieHeader = response.headers.get('Set-Cookie');
      if (setCookieHeader) {
        const match = setCookieHeader.match(/auth_token=([^;]+)/);
        if (match) {
          this.token = match[1];
          document.cookie = `auth_token=${this.token}; path=/`;
        }
      }

      return true;
    } catch (error) {
      return false;
    }
  }

  // ==================== الاتصال الثاني: التهيئة ====================

  async init(): Promise<boolean> {
    if (!this.token) {
      return false;
    }

    // INIT REQUEST 1
    const payload = JSON.stringify({
      "0": {"json": null, "meta": {"values": ["undefined"]}},
      "1": {"json": {"modelFilter": "all"}},
      "2": {"json": null, "meta": {"values": ["undefined"]}},
      "3": {"json": null, "meta": {"values": ["undefined"]}},
      "4": {"json": null, "meta": {"values": ["undefined"]}},
      "5": {"json": null, "meta": {"values": ["undefined"]}},
      "6": {"json": null, "meta": {"values": ["undefined"]}},
    });

    const initUrl1 = "https://mr7.ai/api/trpc/userReviews.shouldShowPopup,chat.list,subscription.status,subscription.canAccessChat,models.list,goldenMoment.status,agent.getSubscription?batch=1&input=" + encodeURIComponent(payload);
    const initHeaders1: Record<string, string> = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'referer': 'https://mr7.ai/chat',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
    };

    try {
      const response = await fetch(initUrl1, {
        method: 'GET',
        headers: initHeaders1,
        credentials: 'include',
      });
      if (response.status === 200) {
        const result = await response.json();
        if (result.length > 2) {
          const sub = result[2]?.result?.data?.json;
          if (sub) {
            this.balance = sub.tokenBalance || this.balance;
          }
        }
      }
    } catch (error) {
      // pass
    }

    // INIT REQUEST 2
    const initUrl2 = 'https://mr7.ai/api/trpc/userReviews.init?batch=1';
    const initHeaders2: Record<string, string> = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/json',
      'origin': 'https://mr7.ai',
      'referer': 'https://mr7.ai/chat',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
    };
    const initData2 = {"0": {"json": null, "meta": {"values": ["undefined"]}}};

    try {
      await fetch(initUrl2, {
        method: 'POST',
        headers: initHeaders2,
        body: JSON.stringify(initData2),
        credentials: 'include',
      });
    } catch (error) {
      // pass
    }

    // INIT REQUEST 3
    this.cache = this.randomUUID();

    const initUrl3 = 'https://manus-analytics.com/api/send';
    const initHeaders3: Record<string, string> = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/json',
      'origin': 'https://mr7.ai',
      'referer': 'https://mr7.ai/',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'cross-site',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-umami-cache': this.cache,
    };
    const initData3 = {
      "type": "event",
      "payload": {
        "website": this.website,
        "screen": "1920x1080",
        "language": "en",
        "title": "mr7.ai - Advanced AI for Security Professionals",
        "hostname": "mr7.ai",
        "url": "https://mr7.ai/chat",
        "referrer": "https://mr7.ai/login"
      }
    };

    try {
      const response = await fetch(initUrl3, {
        method: 'POST',
        headers: initHeaders3,
        body: JSON.stringify(initData3),
      });
      if (response.status === 200) {
        const result = await response.json();
        this.cache = result.cache || this.cache;
      }
    } catch (error) {
      // pass
    }

    return true;
  }

  // ==================== الاتصال الثالث: إنشاء محادثة ====================

  async create(model: string = "free"): Promise<boolean> {
    if (!this.token) {
      return false;
    }

    const url = 'https://mr7.ai/api/trpc/chat.create?batch=1';
    const headers: Record<string, string> = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/json',
      'origin': 'https://mr7.ai',
      'referer': 'https://mr7.ai/chat',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
    };
    const data = {"0": {"json": {"modelType": model}}};

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(data),
        credentials: 'include',
      });
      if (response.status === 200) {
        const result = await response.json();
        this.chat = result[0].result.data.json.id;
        console.log(this.chat);
        return true;
      }
      return false;
    } catch (error) {
      return false;
    }
  }

  // ==================== الاتصال الرابع: إرسال رسالة ====================

  async send(content: string, model: string = "free"): Promise<string | null> {
    if (!this.token) {
      return null;
    }

    if (!this.chat) {
      if (!await this.create(model)) {
        return null;
      }
    }

    const url = 'https://mr7.ai/api/chat/stream';
    const headers: Record<string, string> = {
      'accept': '*/*',
      'accept-language': 'en-US,en;q=0.9',
      'content-type': 'application/json',
      'origin': 'https://mr7.ai',
      'referer': `https://mr7.ai/chat/${this.chat}`,
      'cache-control': 'no-cache',
      'pragma': 'no-cache',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="131", "Chromium";v="131"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.85 Safari/537.36',
      'x-device-fingerprint': this.fingerprint,
    };
    const data = {
      "chatId": this.chat,
      "content": content,
      "modelType": model,
      "attachments": [],
      "deepReasoning": false,
      "webSearch": false,
    };

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(data),
        credentials: 'include',
      });

      if (response.status !== 200) {
        return null;
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');
      let answer = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (!line || !line.startsWith('data:')) continue;
            const raw = line.slice(5).trim();
            if (!raw) continue;
            
            try {
              const event = JSON.parse(raw);
              
              if (event.type === 'chunk') {
                const part = event.content || '';
                if (part) {
                  answer += part;
                }
              } else if (event.type === 'done') {
                const status = event.tokenStatus;
                if (status) {
                  this.balance = status.balance || this.balance;
                }
              }
            } catch (e) {
              continue;
            }
          }
        }
      }

      if (answer) {
        console.log(`\n${answer}`);
        console.log(`\ntoken : ${this.balance}`);
      }

      return answer || null;
    } catch (error) {
      return null;
    }
  }
}