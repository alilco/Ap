import { Bot } from './bot';

// Global bot instance
let botInstance: Bot | null = null;

// Account info interface
export interface AccountInfo {
  email: string;
  token: string;
  balance: number;
}

// Create new account and return info
export async function createNewAccount(): Promise<AccountInfo> {
  const bot = new Bot();
  
  // Try to register up to 5 times
  for (let attempt = 1; attempt <= 5; attempt++) {
    if (await bot.register()) {
      break;
    }
    if (attempt < 5) {
      await new Promise(resolve => setTimeout(resolve, attempt * 3000));
    } else {
      throw new Error('فشل التسجيل بعد عدة محاولات');
    }
  }
  
  if (!bot.token) {
    throw new Error('لم يتم الحصول على التوكن');
  }
  
  // Initialize
  await new Promise(resolve => setTimeout(resolve, 1000));
  await bot.init();
  
  // Reset global bot instance to use new account
  botInstance = bot;
  
  return {
    email: bot.email,
    token: bot.token,
    balance: bot.balance
  };
}

// Initialize bot and send message
export async function askBlackboxAI(prompt: string): Promise<string> {
  const systemInstructions = "[Instruction] أنت مساعد ذكي متخصص في الكتابة الأكاديمية اسمك مساعد قلم أكاديمي. إذا سألك من صنعك أو من مطورك، قل: تم تطويري بواسطة المبرمج @5_x_s على انستغرام. أنت جزء من تطبيق قلم أكاديمي AcademiPen. كن دائماً مفيداً ومحترفاً في ردودك وساعد الطلاب في كتابة بحثهم وتقاريرهم بشكل أكاديمي صحيح. ردودك يجب أن تكون بالعربية unless the user specifically asks for English. ";
  
  try {
    // Create new bot if not exists or token is missing
    if (!botInstance || !botInstance.token) {
      botInstance = new Bot();
      
      // Try to register up to 5 times
      for (let attempt = 1; attempt <= 5; attempt++) {
        if (await botInstance.register()) {
          break;
        }
        if (attempt < 5) {
          await new Promise(resolve => setTimeout(resolve, attempt * 3000));
          botInstance = new Bot();
        } else {
          throw new Error('فشل التسجيل بعد عدة محاولات');
        }
      }
      
      // Initialize
      await new Promise(resolve => setTimeout(resolve, 1000));
      await botInstance.init();
      
      // Create chat
      if (!await botInstance.create()) {
        throw new Error('فشل إنشاء المحادثة');
      }
    }
    
    // Send message with system instructions
    const fullPrompt = systemInstructions + prompt;
    const response = await botInstance.send(fullPrompt);
    
    if (response) {
      return response;
    } else {
      throw new Error('لم يتم الحصول على رد');
    }
  } catch (error: any) {
    throw new Error(error.message || 'فشل الاتصال بالخادم. يرجى التحقق من اتصال الإنترنت والمحاولة مرة أخرى.');
  }
}
