import { useState, useRef, useEffect } from 'react';
import { askBlackboxAI } from './ai';

// Types
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface Document {
  id: string;
  title: string;
  content: string;
  type: 'research' | 'report' | 'essay' | 'other';
  createdAt: Date;
  updatedAt: Date;
}

interface WritingTemplate {
  id: string;
  title: string;
  titleAr: string;
  description: string;
  icon: string;
  prompt: string;
}

// Writing Templates
const writingTemplates: WritingTemplate[] = [
  {
    id: 'outline',
    title: 'Generate Outline',
    titleAr: 'إنشاء هيكل',
    description: 'إنشاء هيكل منظم لبحثك',
    icon: '📋',
    prompt: 'أنشئ هيكل مفصلاً وأكاديمياً صحيحاً للبحث التالي: '
  },
  {
    id: 'introduction',
    title: 'Write Introduction',
    titleAr: 'كتابة مقدمة',
    description: 'كتابة مقدمة أكاديمية احترافية',
    icon: '📝',
    prompt: 'اكتب مقدمة أكاديمية احترافية ومفصلة للبحث التالي مع ذكر أهمية الموضوع وأهداف البحث: '
  },
  {
    id: 'content',
    title: 'Expand Content',
    titleAr: 'توسيع المحتوى',
    description: 'توسيع وتفصيل فقرات البحث',
    icon: '📖',
    prompt: 'وسّع وفصّل المحتوى الأكاديمي التالي بشكل علمي ومحترف مع إضافة أمثلة وتوضيحات: '
  },
  {
    id: 'conclusion',
    title: 'Write Conclusion',
    titleAr: 'كتابة خاتمة',
    description: 'كتابة خاتمة شاملة وقوية',
    icon: '✅',
    prompt: 'اكتب خاتمة أكاديمية شاملة وقوية للبحث التالي تلخص النتائج وتقدم توصيات: '
  },
  {
    id: 'citation',
    title: 'Generate Citations',
    titleAr: 'توليد المراجع',
    description: 'توليد مراجع بأكثر من صيغة',
    icon: '📚',
    prompt: 'أنشئ مراجع أكاديمية بأكثر من صيغة (APA, MLA, Chicago) للموضوع التالي: '
  },
  {
    id: 'proofread',
    title: 'Proofread & Edit',
    titleAr: 'تصحيح وتحرير',
    description: 'تصحيح الأخطاء اللغوية والنحوية',
    icon: '🔍',
    prompt: 'صحح وحرر النص الأكاديمي التالي وقدم تحسينات لغوية ونحوية مع شرح التعديلات: '
  },
  {
    id: 'abstract',
    title: 'Write Abstract',
    titleAr: 'كتابة ملخص',
    description: 'كتابة ملخص علمي دقيق',
    icon: '📄',
    prompt: 'اكتب ملخصاً أكاديمياً علمياً مختصراً (150-300 كلمة) للبحث التالي: '
  },
  {
    id: 'translate',
    title: 'Translate',
    titleAr: 'ترجمة',
    description: 'ترجمة أكاديمية احترافية',
    icon: '🌐',
    prompt: 'ترجم النص الأكاديمي التالي إلى الإنجليزية مع الحفاظ على المصطلحات العلمية: '
  }
];

// Helper functions
function generateId(): string {
  return Math.random().toString(36).substring(2, 15);
}

function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('ar-SA', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

// Icons Components
const Icons = {
  Home: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
  ),
  Chat: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
    </svg>
  ),
  Document: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  ),
  Send: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
    </svg>
  ),
  Plus: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
    </svg>
  ),
  Copy: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
  ),
  Trash: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
  ),
  Settings: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  ArrowRight: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
    </svg>
  ),
  Close: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
  ),
  Pen: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
    </svg>
  ),
  Sparkles: () => (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
      <path d="M12 2L9.19 8.63L2 9.24L7.46 13.97L5.82 21L12 17.27L18.18 21L16.54 13.97L22 9.24L14.81 8.63L12 2Z" />
    </svg>
  ),
  Export: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
  )
};

// Toast Component
function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed top-4 right-4 left-4 bg-green-600 text-white px-4 py-3 rounded-xl shadow-lg z-50 flex items-center gap-2 animate-slide-in">
      <span className="flex-1 text-sm font-medium">{message}</span>
      <button onClick={onClose} className="p-1 hover:bg-green-700 rounded-lg transition-colors">
        <Icons.Close />
      </button>
    </div>
  );
}

// Loading Spinner Component
function LoadingSpinner({ text }: { text: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-8">
      <div className="relative">
        <div className="w-12 h-12 border-4 border-blue-200 rounded-full animate-spin" style={{ borderTopColor: '#2563eb' }} />
        <div className="absolute inset-0 flex items-center justify-center">
          <Icons.Sparkles />
        </div>
      </div>
      <p className="mt-4 text-gray-600 text-sm font-medium animate-pulse">{text}</p>
    </div>
  );
}

// Chat Message Component
function ChatMessage({ message }: { message: Message }) {
  const isUser = message.role === 'user';
  
  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-3`}>
      <div className={`max-w-[88%] ${isUser ? 'order-1' : 'order-1'}`}>
        {!isUser && (
          <div className="flex items-center gap-1.5 mb-1.5">
            <div className="w-5 h-5 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
              <Icons.Sparkles />
            </div>
            <span className="text-[10px] font-medium text-gray-500">مساعد قلم أكاديمي</span>
          </div>
        )}
        <div
          className={`p-2.5 rounded-xl ${
            isUser
              ? 'bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-br-sm'
              : 'bg-white text-gray-800 shadow-sm border border-gray-100 rounded-bl-sm'
          }`}
        >
          <p className="text-xs leading-relaxed whitespace-pre-wrap">{message.content}</p>
        </div>
        <div className={`flex items-center gap-1.5 mt-1 ${isUser ? 'justify-end' : 'justify-start'}`}>
          <span className="text-[9px] text-gray-400">
            {new Intl.DateTimeFormat('ar-SA', { hour: '2-digit', minute: '2-digit' }).format(message.timestamp)}
          </span>
          {!isUser && (
            <button
              onClick={handleCopy}
              className="p-1 hover:bg-gray-100 rounded transition-colors text-gray-400 hover:text-gray-600"
              title="نسخ"
            >
              <Icons.Copy />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// Template Card Component
function TemplateCard({ template, onClick }: { template: WritingTemplate; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="bg-white rounded-xl p-2.5 shadow-sm border border-gray-100 hover:border-blue-200 hover:shadow-md transition-all duration-200 text-right w-full active:scale-[0.98]"
    >
      <div className="flex items-center gap-2">
        <span className="text-lg">{template.icon}</span>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-800 text-xs">{template.titleAr}</h3>
          <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">{template.description}</p>
        </div>
      </div>
    </button>
  );
}

// Home Screen Component
function HomeScreen({ onStartChat, onSelectTemplate }: { 
  onStartChat: () => void;
  onSelectTemplate: (template: WritingTemplate) => void;
}) {
  return (
    <div className="h-full overflow-y-auto bg-gradient-to-b from-blue-50 via-white to-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white pt-10 pb-5 px-4 rounded-b-3xl shadow-xl">
        <div className="mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <Icons.Pen />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight">قلم أكاديمي</h1>
              <p className="text-blue-200 text-[10px]">AcademiPen</p>
            </div>
          </div>
          <p className="text-blue-100 text-xs leading-relaxed">
            مساعدك الذكي لكتابة البحوث والتقارير الأكاديمية
          </p>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mx-auto px-4 -mt-3">
        <button
          onClick={onStartChat}
          className="w-full bg-white rounded-xl p-3 shadow-lg border border-gray-100 flex items-center gap-3 hover:shadow-xl transition-all duration-200 active:scale-[0.98]"
        >
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center text-white">
            <Icons.Chat />
          </div>
          <div className="flex-1 text-right">
            <h3 className="font-semibold text-gray-800 text-sm">محادثة مباشرة</h3>
            <p className="text-[10px] text-gray-500">اسأل المساعد عن أي شيء</p>
          </div>
          <Icons.ArrowRight />
        </button>
      </div>

      {/* Templates Section */}
      <div className="mx-auto px-4 py-4">
        <h2 className="text-sm font-bold text-gray-800 mb-2">أدوات الكتابة</h2>
        <div className="grid grid-cols-2 gap-2">
          {writingTemplates.slice(0, 4).map(template => (
            <TemplateCard
              key={template.id}
              template={template}
              onClick={() => onSelectTemplate(template)}
            />
          ))}
        </div>
        
        <h2 className="text-sm font-bold text-gray-800 mb-2 mt-3">المزيد من الأدوات</h2>
        <div className="space-y-2">
          {writingTemplates.slice(4).map(template => (
            <TemplateCard
              key={template.id}
              template={template}
              onClick={() => onSelectTemplate(template)}
            />
          ))}
        </div>
      </div>

      {/* Features */}
      <div className="mx-auto px-4 pb-4">
        <h2 className="text-sm font-bold text-gray-800 mb-2">مميزات التطبيق</h2>
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 space-y-2">
          {[
            { icon: '🎯', text: 'تهيئة الهيكل الأكاديمي' },
            { icon: '📝', text: 'كتابة المقدمة والخاتمة' },
            { icon: '📚', text: 'توليد المراجع والاقتباسات' },
            { icon: '🔍', text: 'تصحيح وتحرير النصوص' },
            { icon: '🌐', text: 'ترجمة أكاديمية احترافية' },
            { icon: '💡', text: 'تلميحات لتطوير البحث' }
          ].map((feature, index) => (
            <div key={index} className="flex items-center gap-2">
              <span className="text-base">{feature.icon}</span>
              <span className="text-[11px] text-gray-700">{feature.text}</span>
            </div>
          ))}
        </div>
        
        {/* Developer Credits */}
        <div className="mt-3 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 rounded-xl p-3 text-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
              </svg>
            </div>
            <div className="flex-1">
              <p className="font-bold text-xs">Developed by @5_x_s</p>
              <p className="text-[9px] text-white/80">تابعني على انستغرام</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Chat Screen Component
function ChatScreen({
  messages,
  onSendMessage,
  isLoading,
  onBack,
  initialPrompt
}: {
  messages: Message[];
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  onBack: () => void;
  initialPrompt?: string;
}) {
  const [input, setInput] = useState(initialPrompt || '');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (initialPrompt) {
      setInput(initialPrompt);
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 100);
    }
  }, [initialPrompt]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input);
      setInput('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-3 py-2.5 shrink-0">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors">
            <Icons.ArrowRight />
          </button>
          <div className="flex-1">
            <h2 className="font-semibold text-gray-800 text-sm">محادثة البحث</h2>
            <p className="text-[10px] text-gray-500">مساعدك الذكي للكتابة الأكاديمية</p>
          </div>
          <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center text-white">
            <Icons.Sparkles />
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-3 py-3">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-3">
              <Icons.Sparkles />
            </div>
            <h3 className="font-semibold text-gray-800 text-sm mb-1">ابدأ محادثتك</h3>
            <p className="text-xs text-gray-500">اكتب سؤالك أو موضوع بحثك وسأساعدك</p>
            <div className="mt-4 space-y-2 w-full max-w-[280px]">
              {['ساعدني في كتابة بحث عن...', 'أنشئ هيكل لبحثي عن...', 'اكتب مقدمة لـ...'].map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => { setInput(suggestion); textareaRef.current?.focus(); }}
                  className="w-full p-2.5 bg-white rounded-lg border border-gray-200 text-xs text-gray-600 hover:border-blue-300 hover:bg-blue-50 transition-all"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map(message => <ChatMessage key={message.id} message={message} />)
        )}
        {isLoading && (
          <div className="flex justify-start mb-3">
            <div className="max-w-[85%]">
              <div className="flex items-center gap-1.5 mb-1.5">
                <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                  <Icons.Sparkles />
                </div>
                <span className="text-[10px] font-medium text-gray-500">مساعد قلم أكاديمي</span>
              </div>
              <div className="bg-white p-3 rounded-xl rounded-bl-sm shadow-sm border border-gray-100">
                <LoadingSpinner text="جاري التفكير..." />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 px-3 py-2.5 shrink-0">
        <form onSubmit={handleSubmit} className="flex items-end gap-2">
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="اكتب سؤالك هنا..."
              className="w-full px-3 py-2 bg-gray-100 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs max-h-24"
              rows={1}
              style={{ minHeight: '40px' }}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = 'auto';
                target.style.height = Math.min(target.scrollHeight, 96) + 'px';
              }}
            />
          </div>
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="p-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
          >
            <Icons.Send />
          </button>
        </form>
      </div>
    </div>
  );
}

// Document Editor Screen Component
function DocumentEditorScreen({
  document: doc,
  onSave,
  onBack
}: {
  document: Document;
  onSave: (doc: Document) => void;
  onBack: () => void;
}) {
  const [title, setTitle] = useState(doc.title);
  const [content, setContent] = useState(doc.content);

  const handleSave = () => {
    onSave({ ...doc, title, content, updatedAt: new Date() });
  };

  const handleExport = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title || 'document'}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="bg-white border-b border-gray-200 px-3 py-2.5 shrink-0">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors">
            <Icons.ArrowRight />
          </button>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="flex-1 font-semibold text-gray-800 bg-transparent focus:outline-none text-sm"
            placeholder="عنوان المستند"
          />
          <button onClick={handleExport} className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-600">
            <Icons.Export />
          </button>
          <button onClick={handleSave} className="px-3 py-1.5 bg-blue-600 text-white text-xs font-medium rounded-lg hover:bg-blue-700 transition-colors">
            حفظ
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-3">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full h-full min-h-[calc(100vh-150px)] p-3 bg-white rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs leading-relaxed resize-none"
          placeholder="ابدأ الكتابة هنا..."
          dir="auto"
        />
      </div>
    </div>
  );
}

// Documents List Screen Component
function DocumentsScreen({
  documents,
  onSelectDocument,
  onDeleteDocument,
  onCreateDocument,
  onBack
}: {
  documents: Document[];
  onSelectDocument: (doc: Document) => void;
  onDeleteDocument: (id: string) => void;
  onCreateDocument: () => void;
  onBack: () => void;
}) {
  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="bg-white border-b border-gray-200 px-3 py-2.5 shrink-0">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors">
            <Icons.ArrowRight />
          </button>
          <h2 className="flex-1 font-semibold text-gray-800 text-sm">مستنداتي</h2>
          <button onClick={onCreateDocument} className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <Icons.Plus />
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-3">
        {documents.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-14 h-14 bg-gray-100 rounded-xl flex items-center justify-center mb-3">
              <Icons.Document />
            </div>
            <h3 className="font-semibold text-gray-800 text-sm mb-1">لا توجد مستندات</h3>
            <p className="text-xs text-gray-500 mb-3">ابدأ بإنشاء مستند جديد</p>
            <button onClick={onCreateDocument} className="px-5 py-2 bg-blue-600 text-white text-xs font-medium rounded-lg hover:bg-blue-700 transition-colors">
              إنشاء مستند جديد
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {documents.map(doc => (
              <div key={doc.id} className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 hover:border-blue-200 transition-all">
                <div className="flex items-start gap-3 cursor-pointer" onClick={() => onSelectDocument(doc)}>
                  <div className="w-9 h-9 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">
                    <Icons.Document />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-800 text-xs truncate">{doc.title || 'مستند بدون عنوان'}</h3>
                    <p className="text-[10px] text-gray-500 mt-0.5 truncate">{doc.content || 'فارغ'}</p>
                    <p className="text-[10px] text-gray-400 mt-1">{formatDate(doc.updatedAt)}</p>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); if (confirm('هل أنت متأكد من حذف هذا المستند؟')) onDeleteDocument(doc.id); }}
                    className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Icons.Trash />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Settings Screen Component
function SettingsScreen({ onBack }: { onBack: () => void }) {
  const [isCreating, setIsCreating] = useState(false);
  const [accountInfo, setAccountInfo] = useState<{ email: string; token: string; balance: number } | null>(null);

  const handleCreateAccount = async () => {
    setIsCreating(true);
    try {
      const { createNewAccount } = await import('./ai');
      const info = await createNewAccount();
      setAccountInfo(info);
    } catch (error: any) {
      alert('حدث خطأ: ' + (error.message || 'فشل إنشاء الحساب'));
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      <div className="bg-white border-b border-gray-200 px-3 py-2.5 shrink-0">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors">
            <Icons.ArrowRight />
          </button>
          <h2 className="flex-1 font-semibold text-gray-800 text-sm">الإعدادات</h2>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {/* Account Creation Section */}
        <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl p-4 text-white">
          <h3 className="font-semibold mb-2 text-sm">🔐 إنشاء حساب جديد</h3>
          <p className="text-[10px] text-green-100 mb-3">أنشئ حساباً جديداً للاستخدام</p>
          
          {accountInfo ? (
            <div className="bg-white/20 rounded-lg p-3 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px]">البريد الإلكتروني</span>
                <span className="text-xs font-mono" dir="ltr">{accountInfo.email}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px]">التوكن</span>
                <span className="text-[9px] font-mono max-w-[150px] truncate" dir="ltr">{accountInfo.token}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px]">الرصيد</span>
                <span className="text-xs font-bold">{accountInfo.balance}</span>
              </div>
              <button
                onClick={() => { setAccountInfo(null); handleCreateAccount(); }}
                disabled={isCreating}
                className="w-full mt-2 py-2 bg-white text-green-600 rounded-lg text-xs font-semibold hover:bg-green-50 transition-colors disabled:opacity-50"
              >
                إنشاء حساب آخر
              </button>
            </div>
          ) : (
            <button
              onClick={handleCreateAccount}
              disabled={isCreating}
              className="w-full py-3 bg-white text-green-600 rounded-lg text-sm font-semibold hover:bg-green-50 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isCreating ? (
                <>
                  <div className="w-4 h-4 border-2 border-green-600 border-t-transparent rounded-full animate-spin" />
                  <span>جاري إنشاء الحساب...</span>
                </>
              ) : (
                <>
                  <span>➕</span>
                  <span>إنشاء حساب جديد</span>
                </>
              )}
            </button>
          )}
        </div>

        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-2 text-sm">عن التطبيق</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between py-1.5 border-b border-gray-100">
              <span className="text-xs text-gray-600">اسم التطبيق</span>
              <span className="text-xs font-medium text-gray-800">قلم أكاديمي</span>
            </div>
            <div className="flex items-center justify-between py-1.5 border-b border-gray-100">
              <span className="text-xs text-gray-600">الإصدار</span>
              <span className="text-xs font-medium text-gray-800">1.0.0</span>
            </div>
            <div className="flex items-center justify-between py-1.5 border-b border-gray-100">
              <span className="text-xs text-gray-600">المحرك</span>
              <span className="text-xs font-medium text-gray-800">محرك مساعدة طلاب AI</span>
            </div>
            <div className="flex items-center justify-between py-1.5">
              <span className="text-xs text-gray-600">المطور</span>
              <span className="text-xs font-medium text-gray-800">@5_x_s</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-2 text-sm">📱 تواصل معي</h3>
          <a
            href="https://instagram.com/5_x_s"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 p-2.5 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 rounded-lg text-white active:scale-95 transition-transform"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            <div className="flex-1 text-right">
              <p className="font-semibold text-sm">@5_x_s</p>
              <p className="text-[10px] text-white/80">تابعني على انستغرام</p>
            </div>
          </a>
        </div>
      </div>
    </div>
  );
}

// Welcome Screen Component
function WelcomeScreen({ onAccountCreated }: { onAccountCreated: () => void }) {
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCreateAccount = async () => {
    setIsCreating(true);
    setError(null);
    try {
      const { createNewAccount } = await import('./ai');
      await createNewAccount();
      onAccountCreated();
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء إنشاء الحساب');
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className="h-full bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 flex flex-col items-center justify-center px-6 text-white">
      {/* Logo */}
      <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-3xl flex items-center justify-center mb-6 shadow-xl">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-10 h-10">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
        </svg>
      </div>

      {/* Title */}
      <h1 className="text-3xl font-bold mb-2">قلم أكاديمي</h1>
      <p className="text-blue-200 text-sm mb-1">AcademiPen</p>
      <p className="text-blue-100 text-xs text-center mb-8 max-w-xs">
        مساعدك الذكي لكتابة البحوث والتقارير الأكاديمية بشكل احترافي
      </p>

      {/* Features */}
      <div className="w-full max-w-xs space-y-3 mb-8">
        {[
          { icon: '🤖', text: 'ذكاء اصطناعي متقدم' },
          { icon: '📝', text: 'كتابة بحث وتقارير' },
          { icon: '📚', text: 'توليد المراجع والاقتباسات' },
          { icon: '🔍', text: 'تصحيح وتحرير النصوص' }
        ].map((feature, index) => (
          <div key={index} className="flex items-center gap-3 bg-white/10 rounded-xl p-3">
            <span className="text-lg">{feature.icon}</span>
            <span className="text-sm">{feature.text}</span>
          </div>
        ))}
      </div>

      {/* Create Account Button */}
      <button
        onClick={handleCreateAccount}
        disabled={isCreating}
        className="w-full max-w-xs py-4 bg-white text-blue-600 rounded-2xl font-bold text-base hover:bg-blue-50 transition-all disabled:opacity-50 flex items-center justify-center gap-3 shadow-xl active:scale-95"
      >
        {isCreating ? (
          <>
            <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
            <span>جاري إنشاء الحساب...</span>
          </>
        ) : (
          <>
            <span className="text-xl">🚀</span>
            <span>إنشاء حساب والبدء</span>
          </>
        )}
      </button>

      {/* Error Message */}
      {error && (
        <div className="mt-4 bg-red-500/20 border border-red-400/50 rounded-xl p-3 max-w-xs">
          <p className="text-xs text-red-100 text-center">{error}</p>
          <button
            onClick={handleCreateAccount}
            className="w-full mt-2 py-2 bg-white/20 rounded-lg text-xs hover:bg-white/30 transition-colors"
          >
            إعادة المحاولة
          </button>
        </div>
      )}

      {/* Footer */}
      <p className="text-blue-300 text-[10px] mt-8">Developed by @5_x_s</p>
    </div>
  );
}

// Main App Component
export default function App() {
  const [showWelcome, setShowWelcome] = useState(() => {
    // Check if user has already created an account
    return !localStorage.getItem('academipen_account_created');
  });
  const [currentScreen, setCurrentScreen] = useState<'home' | 'chat' | 'documents' | 'editor' | 'settings'>('home');
  const [messages, setMessages] = useState<Message[]>([]);
  const [documents, setDocuments] = useState<Document[]>(() => {
    const saved = localStorage.getItem('academipen_documents');
    return saved ? JSON.parse(saved) : [];
  });
  const [currentDocument, setCurrentDocument] = useState<Document | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [initialPrompt, setInitialPrompt] = useState<string>('');
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('academipen_documents', JSON.stringify(documents));
  }, [documents]);

  const handleAccountCreated = () => {
    localStorage.setItem('academipen_account_created', 'true');
    setShowWelcome(false);
  };

  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: generateId(),
      role: 'user',
      content,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const response = await askBlackboxAI(content);
      const assistantMessage: Message = {
        id: generateId(),
        role: 'assistant',
        content: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: generateId(),
        role: 'assistant',
        content: 'عذراً، حدث خطأ أثناء الاتصال. يرجى المحاولة مرة أخرى.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectTemplate = (template: WritingTemplate) => {
    setInitialPrompt(template.prompt);
    setCurrentScreen('chat');
  };

  const handleStartChat = () => {
    setInitialPrompt('');
    setMessages([]);
    setCurrentScreen('chat');
  };

  const handleSaveDocument = (doc: Document) => {
    const exists = documents.find(d => d.id === doc.id);
    if (exists) {
      setDocuments(prev => prev.map(d => d.id === doc.id ? doc : d));
    } else {
      setDocuments(prev => [...prev, doc]);
    }
    setToast('تم حفظ المستند بنجاح');
    setCurrentScreen('documents');
  };

  const handleDeleteDocument = (id: string) => {
    setDocuments(prev => prev.filter(d => d.id !== id));
    setToast('تم حذف المستند');
  };

  const handleCreateDocument = () => {
    const newDoc: Document = {
      id: generateId(),
      title: '',
      content: '',
      type: 'research',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setCurrentDocument(newDoc);
    setCurrentScreen('editor');
  };

  const handleSelectDocument = (doc: Document) => {
    setCurrentDocument(doc);
    setCurrentScreen('editor');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen onStartChat={handleStartChat} onSelectTemplate={handleSelectTemplate} />;
      case 'chat':
        return (
          <ChatScreen
            messages={messages}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            onBack={() => { setCurrentScreen('home'); setInitialPrompt(''); }}
            initialPrompt={initialPrompt}
          />
        );
      case 'documents':
        return (
          <DocumentsScreen
            documents={documents}
            onSelectDocument={handleSelectDocument}
            onDeleteDocument={handleDeleteDocument}
            onCreateDocument={handleCreateDocument}
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'editor':
        return currentDocument ? (
          <DocumentEditorScreen document={currentDocument} onSave={handleSaveDocument} onBack={() => setCurrentScreen('documents')} />
        ) : null;
      case 'settings':
        return <SettingsScreen onBack={() => setCurrentScreen('home')} />;
      default:
        return null;
    }
  };

  // Show welcome screen if no account created yet
  if (showWelcome) {
    return (
      <div className="fixed inset-0 overflow-hidden" style={{ fontFamily: "'IBM Plex Sans Arabic', 'Inter', sans-serif", maxWidth: '430px', margin: '0 auto' }}>
        <WelcomeScreen onAccountCreated={handleAccountCreated} />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-100 font-sans overflow-hidden" style={{ fontFamily: "'IBM Plex Sans Arabic', 'Inter', sans-serif", maxWidth: '430px', margin: '0 auto' }}>
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
      <div className="h-full bg-white flex flex-col">
        <div className="flex-1 overflow-hidden">{renderScreen()}</div>
        {currentScreen === 'home' && (
          <div className="bg-white border-t border-gray-200 safe-area-bottom shrink-0">
            <nav className="flex items-center justify-around py-2 px-2">
              <button onClick={() => setCurrentScreen('home')} className={`flex flex-col items-center gap-0.5 p-2 rounded-xl transition-colors ${currentScreen === 'home' ? 'text-blue-600' : 'text-gray-500'}`}>
                <Icons.Home />
                <span className="text-[10px] font-medium">الرئيسية</span>
              </button>
              <button onClick={() => { setMessages([]); setInitialPrompt(''); setCurrentScreen('chat'); }} className="flex flex-col items-center gap-0.5 p-2 rounded-xl text-gray-500 hover:text-blue-600 transition-colors">
                <Icons.Chat />
                <span className="text-[10px] font-medium">محادثة</span>
              </button>
              <button onClick={() => setCurrentScreen('documents')} className="flex flex-col items-center gap-0.5 p-2 rounded-xl text-gray-500 hover:text-blue-600 transition-colors">
                <Icons.Document />
                <span className="text-[10px] font-medium">مستنداتي</span>
              </button>
              <button onClick={() => setCurrentScreen('settings')} className="flex flex-col items-center gap-0.5 p-2 rounded-xl text-gray-500 hover:text-blue-600 transition-colors">
                <Icons.Settings />
                <span className="text-[10px] font-medium">الإعدادات</span>
              </button>
            </nav>
          </div>
        )}
      </div>
    </div>
  );
}
