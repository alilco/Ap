import { useState, useRef, useEffect } from 'react';

// Types
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface Document {
  id: string;
  title: string;
  content: string;
  type: 'research' | 'report' | 'essay' | 'other';
  createdAt: Date;
  updatedAt: Date;
}

interface WritingTemplate {
  id: string;
  title: string;
  titleAr: string;
  description: string;
  icon: string;
  prompt: string;
}

// AI API Function - Exact code as provided
async function askBlackboxAI(prompt: string): Promise<string> {
  const url = "https://app.blackbox.ai/api/chat";
  
  const headers = {
    'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36",
    'Content-Type': "application/json",
    'sec-ch-ua-platform': '"Android"',
    'sec-ch-ua': '"Chromium";v="148", "Google Chrome";v="148", "Not/A)Brand";v="99"',
    'sec-ch-ua-mobile': "?1",
    'origin': "https://app.blackbox.ai",
    'sec-fetch-site': "same-origin",
    'sec-fetch-mode': "cors",
    'sec-fetch-dest': "empty",
    'referer': "https://app.blackbox.ai/chat",
    'accept-language': "ar-IQ,ar;q=0.9,en-US;q=0.8,en;q=0.7",
    'priority': "u=1, i"
  };
  
  const payload = {
    "messages": [
      {
        "id": "zciBLadYHbFqKJH6NPJfU",
        "role": "user",
        "content": prompt
      }
    ],
    "id": "dmt0dMX",
    "previewToken": null,
    "userId": null,
    "codeModelMode": true,
    "trendingAgentMode": {},
    "isMicMode": false,
    "maxTokens": 1024,
    "playgroundTopP": null,
    "playgroundTemperature": null,
    "isChromeExt": false,
    "githubToken": "",
    "clickedAnswer2": false,
    "clickedAnswer3": false,
    "clickedForceWebSearch": false,
    "visitFromDelta": false,
    "isMemoryEnabled": false,
    "mobileClient": false,
    "userSelectedModel": null,
    "userSelectedAgent": "VscodeAgent",
    "validated": "a38f5889-8fef-46d4-8ede-bf4668b6a9bb",
    "imageGenerationMode": false,
    "imageGenMode": "autoMode",
    "webSearchModePrompt": false,
    "deepSearchMode": false,
    "promptSelection": "",
    "domains": null,
    "vscodeClient": false,
    "codeInterpreterMode": false,
    "customProfile": {
      "name": "",
      "occupation": "",
      "traits": [],
      "additionalInfo": "",
      "enableNewChats": false
    },
    "webSearchModeOption": {
      "autoMode": true,
      "webMode": false,
      "offlineMode": false
    },
    "session": {
      "user": {
        "name": "ali",
        "email": "a41275050@gmail.com",
        "image": "https://lh3.googleusercontent.com/a/ACg8ocIXjzKpLONG_E4MeKJJwN7_Jikdwms4TLDy-gE_1THWuYPmIQ=s96-c",
        "id": "b5c6e281-2a7a-4333-8491-15aa5ae0c32d"
      },
      "expires": "2026-06-22T09:59:43.053Z",
      "isNewUser": false
    },
    "isPremium": false,
    "teamAccount": "",
    "subscriptionCache": {
      "status": "FREE",
      "customerId": null,
      "expiryTimestamp": null,
      "lastChecked": 1779530367732,
      "isTrialSubscription": false,
      "hasPaymentVerificationFailure": false,
      "verificationFailureTimestamp": null,
      "requiresAuthentication": false,
      "isTeam": false,
      "numSeats": 1,
      "provider": "stripe",
      "previouslySubscribed": false,
      "activeInsuffientCredits": false
    },
    "beastMode": false,
    "reasoningMode": false,
    "designerMode": false,
    "workspaceId": "",
    "asyncMode": false,
    "isTaskPersistent": false,
    "selectedElement": null
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: headers as any,
      body: JSON.stringify(payload)
    });
    
    let fullResponse = await response.text();
    
    // Clean response: remove thinking tags if present
    if (fullResponse.includes('<think>')) {
      const parts = fullResponse.split('</think>');
      if (parts.length > 1) {
        return parts[parts.length - 1].trim();
      }
    }
    
    return fullResponse.trim();
  } catch (error) {
    throw new Error('فشل الاتصال بالخادم. يرجى التحقق من اتصال الإنترنت والمحاولة مرة أخرى.');
  }
}

// Writing Templates
const writingTemplates: WritingTemplate[] = [
  {
    id: 'outline',
    title: 'Generate Outline',
    titleAr: 'إنشاء هيكل',
    description: 'إنشاء هيكل منظم لبحثك',
    icon: '📋',
    prompt: 'أنشئ هيكل مفصلاً وأكاديمياً صحيحاً للبحث التالي: '
  },
  {
    id: 'introduction',
    title: 'Write Introduction',
    titleAr: 'كتابة مقدمة',
    description: 'كتابة مقدمة أكاديمية احترافية',
    icon: '📝',
    prompt: 'اكتب مقدمة أكاديمية احترافية ومفصلة للبحث التالي مع ذكر أهمية الموضوع وأهداف البحث: '
  },
  {
    id: 'content',
    title: 'Expand Content',
    titleAr: 'توسيع المحتوى',
    description: 'توسيع وتفصيل فقرات البحث',
    icon: '📖',
    prompt: 'وسّع وفصّل المحتوى الأكاديمي التالي بشكل علمي ومحترف مع إضافة أمثلة وتوضيحات: '
  },
  {
    id: 'conclusion',
    title: 'Write Conclusion',
    titleAr: 'كتابة خاتمة',
    description: 'كتابة خاتمة شاملة وقوية',
    icon: '✅',
    prompt: 'اكتب خاتمة أكاديمية شاملة وقوية للبحث التالي تلخص النتائج وتقدم توصيات: '
  },
  {
    id: 'citation',
    title: 'Generate Citations',
    titleAr: 'توليد المراجع',
    description: 'توليد مراجع بأكثر من صيغة',
    icon: '📚',
    prompt: 'أنشئ مراجع أكاديمية بأكثر من صيغة (APA, MLA, Chicago) للموضوع التالي: '
  },
  {
    id: 'proofread',
    title: 'Proofread & Edit',
    titleAr: 'تصحيح وتحرير',
    description: 'تصحيح الأخطاء اللغوية والنحوية',
    icon: '🔍',
    prompt: 'صحح وحرر النص الأكاديمي التالي وقدم تحسينات لغوية ونحوية مع شرح التعديلات: '
  },
  {
    id: 'abstract',
    title: 'Write Abstract',
    titleAr: 'كتابة ملخص',
    description: 'كتابة ملخص علمي دقيق',
    icon: '📄',
    prompt: 'اكتب ملخصاً أكاديمياً علمياً مختصراً (150-300 كلمة) للبحث التالي: '
  },
  {
    id: 'translate',
    title: 'Translate',
    titleAr: 'ترجمة',
    description: 'ترجمة أكاديمية احترافية',
    icon: '🌐',
    prompt: 'ترجم النص الأكاديمي التالي إلى الإنجليزية مع الحفاظ على المصطلحات العلمية: '
  }
];

// Helper functions
function generateId(): string {
  return Math.random().toString(36).substring(2, 15);
}

function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('ar-SA', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

// Icons Components
const Icons = {
  Home: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
    </svg>
  ),
  Chat: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
    </svg>
  ),
  Document: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  ),
  Send: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
    </svg>
  ),
  Plus: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
    </svg>
  ),
  Copy: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
  ),
  Trash: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
  ),
  Edit: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
    </svg>
  ),
  Settings: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  ArrowRight: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
    </svg>
  ),
  Loading: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5 animate-spin">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
    </svg>
  ),
  Menu: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
    </svg>
  ),
  Close: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
  ),
  Pen: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-6 h-6">
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
    </svg>
  ),
  Sparkles: () => (
    <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
      <path d="M12 2L9.19 8.63L2 9.24L7.46 13.97L5.82 21L12 17.27L18.18 21L16.54 13.97L22 9.24L14.81 8.63L12 2Z" />
    </svg>
  ),
  Export: () => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
  )
};

// Toast Component
function Toast({ message, onClose }: { message: string; onClose: () => void }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed top-4 right-4 left-4 bg-green-600 text-white px-4 py-3 rounded-xl shadow-lg z-50 flex items-center gap-2 animate-slide-in">
      <span className="flex-1 text-sm font-medium">{message}</span>
      <button onClick={onClose} className="p-1 hover:bg-green-700 rounded-lg transition-colors">
        <Icons.Close />
      </button>
    </div>
  );
}

// Loading Spinner Component
function LoadingSpinner({ text }: { text: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-8">
      <div className="relative">
        <div className="w-12 h-12 border-4 border-blue-200 rounded-full animate-spin" style={{ borderTopColor: '#2563eb' }} />
        <div className="absolute inset-0 flex items-center justify-center">
          <Icons.Sparkles />
        </div>
      </div>
      <p className="mt-4 text-gray-600 text-sm font-medium animate-pulse">{text}</p>
    </div>
  );
}

// Chat Message Component
function ChatMessage({ message }: { message: Message }) {
  const isUser = message.role === 'user';
  
  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-3`}>
      <div className={`max-w-[88%] ${isUser ? 'order-1' : 'order-1'}`}>
        {!isUser && (
          <div className="flex items-center gap-1.5 mb-1.5">
            <div className="w-5 h-5 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
              <Icons.Sparkles />
            </div>
            <span className="text-[10px] font-medium text-gray-500">مساعد قلم أكاديمي</span>
          </div>
        )}
        <div
          className={`p-2.5 rounded-xl ${
            isUser
              ? 'bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-br-sm'
              : 'bg-white text-gray-800 shadow-sm border border-gray-100 rounded-bl-sm'
          }`}
        >
          <p className="text-xs leading-relaxed whitespace-pre-wrap">{message.content}</p>
        </div>
        <div className={`flex items-center gap-1.5 mt-1 ${isUser ? 'justify-end' : 'justify-start'}`}>
          <span className="text-[9px] text-gray-400">
            {new Intl.DateTimeFormat('ar-SA', { hour: '2-digit', minute: '2-digit' }).format(message.timestamp)}
          </span>
          {!isUser && (
            <button
              onClick={handleCopy}
              className="p-1 hover:bg-gray-100 rounded transition-colors text-gray-400 hover:text-gray-600"
              title="نسخ"
            >
              <Icons.Copy />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// Template Card Component
function TemplateCard({ template, onClick }: { template: WritingTemplate; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="bg-white rounded-xl p-2.5 shadow-sm border border-gray-100 hover:border-blue-200 hover:shadow-md transition-all duration-200 text-right w-full active:scale-[0.98]"
    >
      <div className="flex items-center gap-2">
        <span className="text-lg">{template.icon}</span>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-800 text-xs">{template.titleAr}</h3>
          <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">{template.description}</p>
        </div>
      </div>
    </button>
  );
}

// Home Screen Component
function HomeScreen({ onStartChat, onSelectTemplate }: { 
  onStartChat: () => void;
  onSelectTemplate: (template: WritingTemplate) => void;
}) {
  return (
    <div className="h-full overflow-y-auto bg-gradient-to-b from-blue-50 via-white to-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white pt-10 pb-5 px-4 rounded-b-3xl shadow-xl">
        <div className="mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <Icons.Pen />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight">قلم أكاديمي</h1>
              <p className="text-blue-200 text-[10px]">AcademiPen</p>
            </div>
          </div>
          <p className="text-blue-100 text-xs leading-relaxed">
            مساعدك الذكي لكتابة البحوث والتقارير الأكاديمية
          </p>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mx-auto px-4 -mt-3">
        <button
          onClick={onStartChat}
          className="w-full bg-white rounded-xl p-3 shadow-lg border border-gray-100 flex items-center gap-3 hover:shadow-xl transition-all duration-200 active:scale-[0.98]"
        >
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center text-white">
            <Icons.Chat />
          </div>
          <div className="flex-1 text-right">
            <h3 className="font-semibold text-gray-800 text-sm">محادثة مباشرة</h3>
            <p className="text-[10px] text-gray-500">اسأل المساعد عن أي شيء</p>
          </div>
          <Icons.ArrowRight />
        </button>
      </div>

      {/* Templates Section */}
      <div className="mx-auto px-4 py-4">
        <h2 className="text-sm font-bold text-gray-800 mb-2">أدوات الكتابة</h2>
        <div className="grid grid-cols-2 gap-2">
          {writingTemplates.slice(0, 4).map(template => (
            <TemplateCard
              key={template.id}
              template={template}
              onClick={() => onSelectTemplate(template)}
            />
          ))}
        </div>
        
        <h2 className="text-sm font-bold text-gray-800 mb-2 mt-3">المزيد من الأدوات</h2>
        <div className="space-y-2">
          {writingTemplates.slice(4).map(template => (
            <TemplateCard
              key={template.id}
              template={template}
              onClick={() => onSelectTemplate(template)}
            />
          ))}
        </div>
      </div>

      {/* Features */}
      <div className="mx-auto px-4 pb-4">
        <h2 className="text-sm font-bold text-gray-800 mb-2">مميزات التطبيق</h2>
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 space-y-2">
          {[
            { icon: '🎯', text: 'تهيئة الهيكل الأكاديمي' },
            { icon: '📝', text: 'كتابة المقدمة والخاتمة' },
            { icon: '📚', text: 'توليد المراجع والاقتباسات' },
            { icon: '🔍', text: 'تصحيح وتحرير النصوص' },
            { icon: '🌐', text: 'ترجمة أكاديمية احترافية' },
            { icon: '💡', text: 'تلميحات لتطوير البحث' }
          ].map((feature, index) => (
            <div key={index} className="flex items-center gap-2">
              <span className="text-base">{feature.icon}</span>
              <span className="text-[11px] text-gray-700">{feature.text}</span>
            </div>
          ))}
        </div>
        
        {/* Developer Credits */}
        <div className="mt-3 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 rounded-xl p-3 text-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
              </svg>
            </div>
            <div className="flex-1">
              <p className="font-bold text-xs">Developed by @5_x_s</p>
              <p className="text-[9px] text-white/80">تابعني على انستغرام</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Chat Screen Component
function ChatScreen({
  messages,
  onSendMessage,
  isLoading,
  onBack,
  initialPrompt
}: {
  messages: Message[];
  onSendMessage: (message: string) => void;
  isLoading: boolean;
  onBack: () => void;
  initialPrompt?: string;
}) {
  const [input, setInput] = useState(initialPrompt || '');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (initialPrompt) {
      setInput(initialPrompt);
      // Auto-focus textarea when template is selected
      setTimeout(() => {
        textareaRef.current?.focus();
      }, 100);
    }
  }, [initialPrompt]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSendMessage(input);
      setInput('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="flex flex-col h-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-3 py-2.5 shrink-0">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            className="p-1.5 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Icons.ArrowRight />
          </button>
          <div className="flex-1">
            <h2 className="font-semibold text-gray-800 text-sm">محادثة البحث</h2>
            <p className="text-[10px] text-gray-500">مساعدك الذكي للكتابة الأكاديمية</p>
          </div>
          <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center text-white">
            <Icons.Sparkles />
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-3 py-3">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-4">
            <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-3">
              <Icons.Sparkles />
            </div>
            <h3 className="font-semibold text-gray-800 text-sm mb-1">ابدأ محادثتك</h3>
            <p className="text-xs text-gray-500">
              اكتب سؤالك أو موضوع بحثك وسأساعدك
            </p>
            <div className="mt-4 space-y-2 w-full max-w-[280px]">
              {[
                'ساعدني في كتابة بحث عن...',
                'أنشئ هيكل لبحثي عن...',
                'اكتب مقدمة لـ...'
              ].map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setInput(suggestion);
                    textareaRef.current?.focus();
                  }}
                  className="w-full p-2.5 bg-white rounded-lg border border-gray-200 text-xs text-gray-600 hover:border-blue-300 hover:bg-blue-50 transition-all"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map(message => (
            <ChatMessage key={message.id} message={message} />
          ))
        )}
        {isLoading && (
          <div className="flex justify-start mb-3">
            <div className="max-w-[85%]">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="w-6 h-6 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                  <Icons.Sparkles />
                </div>
                <span className="text-[10px] font-medium text-gray-500">مساعد قلم أكاديمي</span>
              </div>
              <div className="bg-white p-3 rounded-xl rounded-bl-sm shadow-sm border border-gray-100">
                <LoadingSpinner text="جاري التفكير..." />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 px-3 py-2.5 shrink-0">
        <form onSubmit={handleSubmit} className="flex items-end gap-2">
          <div className="flex-1 relative">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="اكتب سؤالك هنا..."
              className="w-full px-3 py-2 bg-gray-100 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs max-h-24"
              rows={1}
              style={{ minHeight: '40px' }}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = 'auto';
                target.style.height = Math.min(target.scrollHeight, 96) + 'px';
              }}
            />
          </div>
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="p-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed active:scale-95"
          >
            <Icons.Send />
          </button>
        </form>
      </div>
    </div>
  );
}

// Document Editor Screen Component
function DocumentEditorScreen({
  document: doc,
  onSave,
  onBack
}: {
  document: Document;
  onSave: (doc: Document) => void;
  onBack: () => void;
}) {
  const [title, setTitle] = useState(doc.title);
  const [content, setContent] = useState(doc.content);

  const handleSave = () => {
    onSave({ ...doc, title, content, updatedAt: new Date() });
  };

  const handleExport = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title || 'document'}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <Icons.ArrowRight />
          </button>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="flex-1 font-semibold text-gray-800 bg-transparent focus:outline-none"
            placeholder="عنوان المستند"
          />
          <button
            onClick={handleExport}
            className="p-2 hover:bg-gray-100 rounded-xl transition-colors text-gray-600"
          >
            <Icons.Export />
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-xl hover:bg-blue-700 transition-colors"
          >
            حفظ
          </button>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 overflow-y-auto p-4">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full h-full min-h-[calc(100vh-200px)] p-4 bg-white rounded-2xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm leading-relaxed resize-none"
          placeholder="ابدأ الكتابة هنا..."
          dir="auto"
        />
      </div>
    </div>
  );
}

// Documents List Screen Component
function DocumentsScreen({
  documents,
  onSelectDocument,
  onDeleteDocument,
  onCreateDocument,
  onBack
}: {
  documents: Document[];
  onSelectDocument: (doc: Document) => void;
  onDeleteDocument: (id: string) => void;
  onCreateDocument: () => void;
  onBack: () => void;
}) {
  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <Icons.ArrowRight />
          </button>
          <h2 className="flex-1 font-semibold text-gray-800">مستنداتي</h2>
          <button
            onClick={onCreateDocument}
            className="p-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
          >
            <Icons.Plus />
          </button>
        </div>
      </div>

      {/* Documents List */}
      <div className="flex-1 overflow-y-auto p-4">
        {documents.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mb-4">
              <Icons.Document />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">لا توجد مستندات</h3>
            <p className="text-sm text-gray-500 mb-4">ابدأ بإنشاء مستند جديد</p>
            <button
              onClick={onCreateDocument}
              className="px-6 py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 transition-colors"
            >
              إنشاء مستند جديد
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {documents.map(doc => (
              <div
                key={doc.id}
                className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:border-blue-200 transition-all"
              >
                <div
                  className="flex items-start gap-3 cursor-pointer"
                  onClick={() => onSelectDocument(doc)}
                >
                  <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
                    <Icons.Document />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-800 truncate">{doc.title || 'مستند بدون عنوان'}</h3>
                    <p className="text-xs text-gray-500 mt-1 truncate">{doc.content || 'فارغ'}</p>
                    <p className="text-xs text-gray-400 mt-2">{formatDate(doc.updatedAt)}</p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      if (confirm('هل أنت متأكد من حذف هذا المستند؟')) {
                        onDeleteDocument(doc.id);
                      }
                    }}
                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                  >
                    <Icons.Trash />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Settings Screen Component
function SettingsScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
          >
            <Icons.ArrowRight />
          </button>
          <h2 className="flex-1 font-semibold text-gray-800">الإعدادات</h2>
        </div>
      </div>

      {/* Settings Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* About */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-3">عن التطبيق</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">اسم التطبيق</span>
              <span className="text-sm font-medium text-gray-800">قلم أكاديمي</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">الإصدار</span>
              <span className="text-sm font-medium text-gray-800">1.0.0</span>
            </div>
            <div className="flex items-center justify-between py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">المحرك</span>
              <span className="text-sm font-medium text-gray-800">محرك مساعدة طلاب AI</span>
            </div>
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-gray-600">المطور</span>
              <span className="text-sm font-medium text-gray-800">5_x_s</span>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-3">الميزات</h3>
          <div className="space-y-3 text-sm text-gray-600">
            <p>✅ مساعدة في كتابة البحوث والتقارير</p>
            <p>✅ إنشاء الهياكل الأكاديمية</p>
            <p>✅ توليد المراجع والاقتباسات</p>
            <p>✅ تصحيح وتحرير النصوص</p>
            <p>✅ ترجمة أكاديمية احترافية</p>
            <p>✅ حفظ وتصدير المستندات</p>
          </div>
        </div>

        {/* Tips */}
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl p-4 text-white">
          <h3 className="font-semibold mb-2">💡 نصائح للاستخدام</h3>
          <ul className="text-sm text-blue-100 space-y-2">
            <li>• كن محدداً في موضوع بحثك للحصول على نتائج أفضل</li>
            <li>• استخدم الأدوات المختلفة حسب احتياجك</li>
            <li>• راجع وحرر النص قبل التسليم النهائي</li>
            <li>• احفظ عملك بانتظام</li>
          </ul>
        </div>

        {/* Contact */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-3">📱 تواصل معي</h3>
          <a
            href="https://instagram.com/5_x_s"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-3 p-3 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 rounded-xl text-white active:scale-95 transition-transform"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            <div className="flex-1 text-right">
              <p className="font-semibold">@5_x_s</p>
              <p className="text-xs text-white/80">تابعني على انستغرام</p>
            </div>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5 rotate-180">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>


      </div>
    </div>
  );
}

// Main App Component
export default function App() {
  // State
  const [currentScreen, setCurrentScreen] = useState<'home' | 'chat' | 'documents' | 'editor' | 'settings'>('home');
  const [messages, setMessages] = useState<Message[]>([]);
  const [documents, setDocuments] = useState<Document[]>(() => {
    const saved = localStorage.getItem('academipen_documents');
    return saved ? JSON.parse(saved) : [];
  });
  const [currentDocument, setCurrentDocument] = useState<Document | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [initialPrompt, setInitialPrompt] = useState<string>('');
  const [toast, setToast] = useState<string | null>(null);

  // Save documents to localStorage
  useEffect(() => {
    localStorage.setItem('academipen_documents', JSON.stringify(documents));
  }, [documents]);

  // System instructions for AI
  const systemInstructions = "[Instruction] أنت مساعد ذكي متخصص في الكتابة الأكاديمية اسمك مساعد قلم أكاديمي. إذا سألك من صنعك أو من مطورك، قل: تم تطويري بواسطة المبرمج @5_x_s على انستغرام. أنت جزء من تطبيق قلم أكاديمي AcademiPen. كن دائماً مفيداً ومحترفاً في ردودك وساعد الطلاب في كتابة بحثهم وتقاريرهم بشكل أكاديمي صحيح. ردودك يجب أن تكون بالعربية unless the user specifically asks for English. ";

  // Handle sending message
  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: generateId(),
      role: 'user',
      content,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      // Prepend system instructions to the prompt
      const fullPrompt = systemInstructions + content;
      const response = await askBlackboxAI(fullPrompt);
      const assistantMessage: Message = {
        id: generateId(),
        role: 'assistant',
        content: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: generateId(),
        role: 'assistant',
        content: 'عذراً، حدث خطأ أثناء الاتصال. يرجى التحقق من اتصال الإنترنت والمحاولة مرة أخرى.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle template selection
  const handleSelectTemplate = (template: WritingTemplate) => {
    setInitialPrompt(template.prompt);
    setCurrentScreen('chat');
  };

  // Handle start chat
  const handleStartChat = () => {
    setInitialPrompt('');
    setMessages([]);
    setCurrentScreen('chat');
  };

  // Handle save document
  const handleSaveDocument = (doc: Document) => {
    const exists = documents.find(d => d.id === doc.id);
    if (exists) {
      setDocuments(prev => prev.map(d => d.id === doc.id ? doc : d));
    } else {
      setDocuments(prev => [...prev, doc]);
    }
    setToast('تم حفظ المستند بنجاح');
    setCurrentScreen('documents');
  };

  // Handle delete document
  const handleDeleteDocument = (id: string) => {
    setDocuments(prev => prev.filter(d => d.id !== id));
    setToast('تم حذف المستند');
  };

  // Handle create document
  const handleCreateDocument = () => {
    const newDoc: Document = {
      id: generateId(),
      title: '',
      content: '',
      type: 'research',
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setCurrentDocument(newDoc);
    setCurrentScreen('editor');
  };

  // Handle select document
  const handleSelectDocument = (doc: Document) => {
    setCurrentDocument(doc);
    setCurrentScreen('editor');
  };

  // Render current screen
  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <HomeScreen
            onStartChat={handleStartChat}
            onSelectTemplate={handleSelectTemplate}
          />
        );
      case 'chat':
        return (
          <ChatScreen
            messages={messages}
            onSendMessage={handleSendMessage}
            isLoading={isLoading}
            onBack={() => {
              setCurrentScreen('home');
              setInitialPrompt('');
            }}
            initialPrompt={initialPrompt}
          />
        );
      case 'documents':
        return (
          <DocumentsScreen
            documents={documents}
            onSelectDocument={handleSelectDocument}
            onDeleteDocument={handleDeleteDocument}
            onCreateDocument={handleCreateDocument}
            onBack={() => setCurrentScreen('home')}
          />
        );
      case 'editor':
        return currentDocument ? (
          <DocumentEditorScreen
            document={currentDocument}
            onSave={handleSaveDocument}
            onBack={() => setCurrentScreen('documents')}
          />
        ) : null;
      case 'settings':
        return (
          <SettingsScreen onBack={() => setCurrentScreen('home')} />
        );
      default:
        return null;
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-gray-100 font-sans overflow-hidden"
      style={{ 
        fontFamily: "'IBM Plex Sans Arabic', 'Inter', sans-serif",
        maxWidth: '430px',
        margin: '0 auto'
      }}
    >
      {/* Toast */}
      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
      
      {/* Main Content - Full Screen Mobile */}
      <div className="h-full bg-white flex flex-col">
        <div className="flex-1 overflow-hidden">
          {renderScreen()}
        </div>

        {/* Bottom Navigation - Only show on home screen */}
        {currentScreen === 'home' && (
          <div className="bg-white border-t border-gray-200 safe-area-bottom shrink-0">
            <nav className="flex items-center justify-around py-2 px-2">
              <button
                onClick={() => setCurrentScreen('home')}
                className={`flex flex-col items-center gap-0.5 p-2 rounded-xl transition-colors ${
                  currentScreen === 'home' ? 'text-blue-600' : 'text-gray-500'
                }`}
              >
                <Icons.Home />
                <span className="text-[10px] font-medium">الرئيسية</span>
              </button>
              <button
                onClick={() => {
                  setMessages([]);
                  setInitialPrompt('');
                  setCurrentScreen('chat');
                }}
                className="flex flex-col items-center gap-0.5 p-2 rounded-xl text-gray-500 hover:text-blue-600 transition-colors"
              >
                <Icons.Chat />
                <span className="text-[10px] font-medium">محادثة</span>
              </button>
              <button
                onClick={() => setCurrentScreen('documents')}
                className="flex flex-col items-center gap-0.5 p-2 rounded-xl text-gray-500 hover:text-blue-600 transition-colors"
              >
                <Icons.Document />
                <span className="text-[10px] font-medium">مستنداتي</span>
              </button>
              <button
                onClick={() => setCurrentScreen('settings')}
                className="flex flex-col items-center gap-0.5 p-2 rounded-xl text-gray-500 hover:text-blue-600 transition-colors"
              >
                <Icons.Settings />
                <span className="text-[10px] font-medium">الإعدادات</span>
              </button>
            </nav>
          </div>
        )}
      </div>
    </div>
  );
}
